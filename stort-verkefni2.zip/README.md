Stórt-Verkefni 2 í **Vefforritun (TÖL107G)** hjá Háskóla Íslands

***

## Authors

\- [Alexandra Mjöll Young](https://github.com/meatyminx) <br>
\- [Hyo sam Nandkisore](https://github.com/hyn1)

